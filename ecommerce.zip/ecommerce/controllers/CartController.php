<?php
include_once 'models/Cart.php';

class CartController {
    private $db;
    private $cart;

    public function __construct($db){
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $this->db = $db;
        $this->cart = new Cart($this->db);
    }

    public function addToCart(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $this->cart->user_id = $_SESSION['user_id'];
            $this->cart->product_id = $_POST['product_id'];
            $this->cart->quantity = $_POST['quantity'] ?? 1;

            if($this->cart->add()){
                header('Location: index.php?action=view_cart');
                exit();
            } else {
                echo "Error: Unable to add to cart.";
            }
        }
    }

    public function viewCart(){
        $cartItems = $this->cart->getItems($_SESSION['user_id']);
        include 'views/cart/view.php';
    }

    public function removeFromCart($id){
        if($this->cart->remove($id)){
            header('Location: index.php?action=view_cart');
            exit();
        } else {
            echo "Error: Unable to remove from cart.";
        }
    }

    public function checkout(){
        // Récupérer les articles du panier
        $cartItems = $this->cart->getItems($_SESSION['user_id']);

        // Calculer le montant total du panier
        $total_amount = 0;
        foreach ($cartItems as $item) {
            $total_amount += $item['quantity'] * $item['price'];
        }
        $total_amount = number_format($total_amount, 2, '.', '');

        // Passer les articles du panier et le montant total à la vue
        include 'views/cart/checkout.php';
    }

    public function processCheckout(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            // Logic for processing the payment
            // This is just a placeholder, you need to integrate with a payment gateway
            $card_number = $_POST['card_number'];
            $expiry_date = $_POST['expiry_date'];
            $cvv = $_POST['cvv'];
            $cardholder_name = $_POST['cardholder_name'];
            $billing_address = $_POST['billing_address'];

            // Here you would normally process the payment and clear the cart
            // For now, we'll just clear the cart

            $this->cart->clearCart($_SESSION['user_id']);

            echo "Payment processed successfully!";
        }
    }
}
?>
