<?php
include_once 'models/Product.php';

class ProductController {
    private $db;
    private $product;

    public function __construct($db){
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $this->db = $db;
        $this->product = new Product($this->db);
    }

    public function addProduct(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $this->product->name = $_POST['name'];
            $this->product->description = $_POST['description'];
            $this->product->price = $_POST['price'];
            $this->product->image = $_POST['image'];

            if($this->product->create()){
                header('Location: index.php?action=home');
            } else {
                echo "Error: Unable to add product.";
            }
        } else {
            include 'views/products/add.php';
        }
    }

    public function editProduct($id){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $this->product->id = $id;
            $this->product->name = $_POST['name'];
            $this->product->description = $_POST['description'];
            $this->product->price = $_POST['price'];
            $this->product->image = $_POST['image'];

            if($this->product->update()){
                header('Location: index.php?action=home');
            } else {
                echo "Error: Unable to update product.";
            }
        } else {
            $product = $this->product->getById($id);
            include 'views/products/edit.php';
        }
    }

    public function deleteProduct($id){
        $this->product->id = $id;
        if($this->product->delete()){
            header('Location: index.php?action=home');
        } else {
            echo "Error: Unable to delete product.";
        }
    }

    public function home(){
        $products = $this->product->getAll();
        include 'views/products/home.php';
    }
}
?>
