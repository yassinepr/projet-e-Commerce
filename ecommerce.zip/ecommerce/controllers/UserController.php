<?php
include_once 'models/User.php';

class UserController {
    private $db;
    private $user;

    public function __construct($db){
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $this->db = $db;
        $this->user = new User($this->db);
    }

    public function register(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $this->user->username = $_POST['username'];
            $this->user->password = $_POST['password'];  // Pas de hachage
            $this->user->email = $_POST['email'];
            $this->user->role = $_POST['role'];  // Rôle défini par le formulaire

            if($this->user->register()){
                header('Location: index.php?action=login');
            } else {
                echo "Error: Registration failed.";
            }
        } else {
            include 'views/users/register.php';
        }
    }

    public function login(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $this->user->username = $_POST['username'];
            $this->user->password = $_POST['password'];

            $user = $this->user->login();
            if($user){
                if($this->user->password === $user['password']){  // Comparaison des mots de passe en clair
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['welcome_message'] = "Welcome, " . $user['username'] . "!";
                    header('Location: index.php?action=home');
                    exit();
                } else {
                    $_SESSION['error_message'] = "Error: Incorrect password.";
                    header('Location: index.php?action=login');
                    exit();
                }
            } else {
                $_SESSION['error_message'] = "Error: User not found.";
                header('Location: index.php?action=login');
                exit();
            }
        } else {
            include 'views/users/login.php';
        }
    }

    public function logout(){
        session_destroy();
        header('Location: index.php?action=login');
        exit();
    }
}
?>
