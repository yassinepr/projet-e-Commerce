<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        .payment-container {
            max-width: 600px;
            width: 100%;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 0 auto;
        }
        .payment-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .payment-header h1 {
            margin: 0;
            font-size: 24px;
        }
        .payment-icons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        .payment-icons i {
            font-size: 2em;
            color: #007bff;
        }
        .payment-form {
            width: 100%;
        }
        .payment-form label {
            display: block;
            margin-bottom: 5px;
        }
        .payment-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .payment-form .form-group {
            margin-bottom: 20px;
        }
        .payment-form button {
            width: 100%;
            padding: 15px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1.2em;
            cursor: pointer;
        }
        .payment-form button:hover {
            background-color: #0056b3;
        }
        .cart-summary {
            display: flex;
            align-items: center;
            color: #007bff;
        }
        .cart-summary i {
            font-size: 1.5em;
        }
        .cart-summary span {
            margin-left: 5px;
            font-size: 1.2em;
        }
    </style>
</head>
<body>
    <?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    $total_items = 0;
    $total_price = 0.00;

    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        // Connect to the database
        include_once ROOT_PATH . '/config/database.php';
        $database = new Database();
        $db = $database->getConnection();

        // Query to get the total items and price
        $query = "SELECT SUM(cart.quantity) AS total_items, SUM(cart.quantity * products.price) AS total_price
                  FROM cart
                  JOIN products ON cart.product_id = products.id
                  WHERE cart.user_id = :user_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $total_items = $result['total_items'] ?? 0;
        $total_price = $result['total_price'] ?? 0.00;
    }
    ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php?action=home">E-commerce</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=view_cart">
                            <div class="cart-summary">
                                <i class="fas fa-shopping-cart"></i>
                                <span><?php echo $total_items; ?> items - $<?php echo number_format($total_price, 2); ?></span>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=logout">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=login">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=register">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</body>
</html>
