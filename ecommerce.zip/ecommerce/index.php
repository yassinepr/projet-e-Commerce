<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('ROOT_PATH', __DIR__);

include_once 'config/database.php';
include_once 'controllers/ProductController.php';
include_once 'controllers/UserController.php';
include_once 'controllers/CartController.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$database = new Database();
$db = $database->getConnection();

$productController = new ProductController($db);
$userController = new UserController($db);
$cartController = new CartController($db);

$action = isset($_GET['action']) ? $_GET['action'] : 'login'; // Par défaut, rediriger vers la page de login

// Actions protégées qui nécessitent une connexion
$protected_actions = ['add_product', 'edit_product', 'delete_product', 'add_to_cart', 'view_cart', 'remove_from_cart', 'checkout', 'process_checkout', 'process_payment'];
if (!isset($_SESSION['user_id']) && in_array($action, $protected_actions)) {
    header('Location: index.php?action=login');
    exit();
}

// Vérifier le rôle de l'utilisateur pour accéder aux actions d'administration
if (in_array($action, ['add_product', 'edit_product', 'delete_product']) && (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin')) {
    $action = 'home';
}

switch ($action) {
    case 'register':
        $userController->register();
        break;
    case 'login':
        $userController->login();
        break;
    case 'logout':
        $userController->logout();
        break;
    case 'add_product':
        $productController->addProduct();
        break;
    case 'edit_product':
        $productController->editProduct($_GET['id']);
        break;
    case 'delete_product':
        $productController->deleteProduct($_GET['id']);
        break;
    case 'add_to_cart':
        $cartController->addToCart();
        break;
    case 'view_cart':
        $cartController->viewCart();
        break;
    case 'remove_from_cart':
        $cartController->removeFromCart($_GET['id']);
        break;
    case 'checkout':
        $cartController->checkout();
        break;
    case 'process_checkout':
        $cartController->processCheckout();
        break;
    case 'process_payment':
        // Process payment logic can be implemented here
        echo "Payment processed successfully!";
        break;
    case 'home':
        $productController->home();
        break;
    default:
        $userController->login();
        break;
}
?>
