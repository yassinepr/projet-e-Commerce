<?php
// checkout.php
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de Paiement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        h1 {
            color: #333;
        }

        #paypal-button-container {
            margin-top: 20px;
        }

        #amount-display {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Page de Paiement</h1>

    <!-- Affichage du montant total -->
    <div id="amount-display">
        Montant à payer : <span id="amount-value"><?php echo $total_amount; ?></span> $
    </div>

    <div id="paypal-button-container"></div>

    <script src="https://www.paypal.com/sdk/js?client-id=AeBn97n7hogUs5SP4hDTeqtw1aMVisxIzkCAizQusH6nlQm9iIqf8r729ZfnMxNcmTSktB5IbX5JyM9k"></script>
    <script>
        // Utiliser PHP pour obtenir le montant réel du panier
        var paymentAmount = "<?php echo $total_amount; ?>";

        // Affichage du montant sur la page
        document.getElementById('amount-value').innerText = paymentAmount;

        paypal.Buttons({
            createOrder: function (data, actions) {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: paymentAmount
                        }
                    }]
                });
            },
            onApprove: function (data, actions) {
                return actions.order.capture().then(function (details) {
                    alert('Transaction complétée par ' + details.payer.name.given_name + ' pour un montant de ' + paymentAmount + ' USD!');
                });
            },
            onError: function(err) {
                console.log("Erreur dans le paiement", err);
                alert("Paiement échoué");
            }
        }).render('#paypal-button-container');
    </script>
</body>
</html>
