<?php include ROOT_PATH . '/includes/header.php'; ?>
<div class="container mt-5">
    <h2>Cart</h2>
    <?php if (count($cartItems) > 0): ?>
        <ul class="list-group">
            <?php foreach ($cartItems as $item): ?>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-md-2">
                            <img src="<?php echo $item['image']; ?>" class="img-fluid" alt="<?php echo $item['name']; ?>">
                        </div>
                        <div class="col-md-8">
                            <h5><?php echo $item['name']; ?></h5>
                            <p><?php echo $item['description']; ?></p>
                            <p>Price: $<?php echo $item['price']; ?></p>
                            <p>Quantity: <?php echo $item['quantity']; ?></p>
                        </div>
                        <div class="col-md-2">
                            <form action="index.php?action=remove_from_cart&id=<?php echo $item['cart_id']; ?>" method="POST">
                                <button type="submit" class="btn btn-danger">Remove</button>
                            </form>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
        <div class="mt-4">
            <a href="index.php?action=checkout" class="btn btn-primary btn-block">Proceed to Checkout</a>
        </div>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>
<?php include ROOT_PATH . '/includes/footer.php'; ?>
