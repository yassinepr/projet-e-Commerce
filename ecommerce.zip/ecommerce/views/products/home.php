<?php include ROOT_PATH . '/includes/header.php'; ?>
<div class="container mt-5">
    <?php if (isset($_SESSION['welcome_message'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['welcome_message']; unset($_SESSION['welcome_message']); ?>
        </div>
    <?php endif; ?>
    <div class="row">
        <?php foreach ($products as $product): ?>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="<?php echo $product['image']; ?>" class="card-img-top" alt="<?php echo $product['name']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $product['name']; ?></h5>
                        <p class="card-text"><?php echo $product['description']; ?></p>
                        <p class="card-text">Price: $<?php echo $product['price']; ?></p>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                            <a href="index.php?action=edit_product&id=<?php echo $product['id']; ?>" class="btn btn-primary">Edit</a>
                            <a href="index.php?action=delete_product&id=<?php echo $product['id']; ?>" class="btn btn-danger">Delete</a>
                        <?php else: ?>
                            <form action="index.php?action=add_to_cart" method="POST">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <button type="submit" class="btn btn-success">Add to Cart</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <div class="row">
            <div class="col-md-12">
                <a href="index.php?action=add_product" class="btn btn-success btn-block">Add New Product</a>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php include ROOT_PATH . '/includes/footer.php'; ?>
