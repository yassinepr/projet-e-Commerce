<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once 'config/database.php';
include_once 'controllers/ProductController.php';
include_once 'controllers/UserController.php';
include_once 'controllers/CartController.php';

$database = new Database();
$db = $database->getConnection();

$productController = new ProductController($db);
$userController = new UserController($db);
$cartController = new CartController($db);

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'register':
        $userController->register();
        break;
    case 'login':
        $userController->login();
        break;
    case 'logout':
        $userController->logout();
        break;
    case 'add_to_cart':
        $cartController->add();
        break;
    case 'remove_from_cart':
        $cartController->remove($_POST['id']);
        break;
    case 'view_cart':
        $cartController->index();
        break;
    case 'checkout':
        include 'views/cart/checkout.php';
        break;
    case 'process_payment':
        // Ajoutez ici le traitement du paiement
        echo "Payment processed.";
        break;
    case 'home':
        $productController->home();
        break;
    case 'add_product':
        $productController->addProduct();
        break;
    default:
        $userController->login();
        break;
}
?>
